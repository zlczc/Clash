### clash.ini与clash_lite.ini的区别
clash.ini：增强广告拦截、隐私防护及完整GFW代理列表，总规则4.5W条，适合PC端使用（不受性能、功耗限制）；

clash_lite.ini：精简广告拦截，总规则8.5K条，适合移动端使用（减少规则匹配，节省功耗）。

**注：**[clash_conf/stash/stash.ini](https://github.com/yorunning/clash_conf/blob/main/stash/stash.ini)为clash_lite.ini的硬链接，内容一样。
