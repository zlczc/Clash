# Clash
常用的clash模板配置


1.Mini模板(无自动测速)

https://api.dler.io/sub?target=clash&url=替换成你的订阅&config=https://raw.githubusercontent.com/ldsoy/Clash/main/shenseven/Mini.ini

效果图：

<img src="https://user-images.githubusercontent.com/67219859/177072619-7f1ed3f1-3224-4778-be01-3c0d4cb9f547.png" width="80%" >


2.Mini_auto模板(有自动测速，不想手动选的用这个)

https://api.dler.io/sub?target=clash&url=替换成你的订阅&config=https://raw.githubusercontent.com/ldsoy/Clash/main/shenseven/Mini_auto.ini

效果图：

<img src="https://user-images.githubusercontent.com/67219859/177072671-a466f0e2-42c6-423c-9f7c-487bbff63a06.png" width="80%">


3.NetFlix模板(无自动测速，有奈飞分流)

https://api.dler.io/sub?target=clash&url=替换成你的订阅&config=https://raw.githubusercontent.com/ldsoy/Clash/main/shenseven/NetFilx.ini

效果图：

<img src="https://user-images.githubusercontent.com/67219859/177072920-9e544709-4ed8-44fa-9958-7b525dec351c.png" width="80%">


