# Clash个人配置

基础用法：

1、前往 https://acl4ssr-sub.github.io/

2、填入订阅链接

3、远程配置填写为 https://raw.githubusercontent.com/123456qewret/Clash/main/output 

4、选择一个喜欢的后端

5、生成订阅导入clash
